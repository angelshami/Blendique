-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Nov 22, 2026 at 06:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blendique`
--

-- --------------------------------------------------------

--
-- Table structure for table `beverages`
--

CREATE TABLE `beverages` (
  `beverage_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `size` varchar(30) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `beverages`
--

INSERT INTO `beverages` (`beverage_id`, `name`, `description`, `size`, `price`) VALUES
(1, 'Cappuccino', 'Espresso with steamed milk and foam', 'Medium', 160.00),
(2, 'Vanilla Latte', 'Smooth latte with vanilla syrup', 'Medium', 180.00),
(3, 'Mocha', 'Chocolate flavored coffee', 'Large', 200.00),
(4, 'Cold Coffee', 'Chilled creamy coffee', 'Large', 170.00),
(5, 'Americano', 'Espresso with hot water', 'Medium', 130.00),
(6, 'Caramel Latte', 'Latte with caramel syrup', 'Medium', 190.00);

-- --------------------------------------------------------

--
-- Table structure for table `cafe_locations`
--

CREATE TABLE `cafe_locations` (
  `id` int(11) NOT NULL,
  `cafe_name` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `opening_hours` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `map_url` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cafe_locations`
--

INSERT INTO `cafe_locations` (`id`, `cafe_name`, `area`, `address`, `opening_hours`, `phone`, `map_url`, `is_active`) VALUES
(1, 'Bandra Flagship', 'Bandra West', 'Enter your actual café address here', '10:30 AM - 10:00 PM', 'Enter phone number', 'https://www.google.com/maps', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customizations`
--

CREATE TABLE `customizations` (
  `customization_id` int(11) NOT NULL,
  `order_item_id` int(11) NOT NULL,
  `milk_option` varchar(50) DEFAULT NULL,
  `coffee_strength` varchar(30) DEFAULT NULL,
  `sweetness` varchar(30) DEFAULT NULL,
  `syrup` varchar(50) DEFAULT NULL,
  `toppings` varchar(100) DEFAULT NULL,
  `special_instructions` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customizations`
--

INSERT INTO `customizations` (`customization_id`, `order_item_id`, `milk_option`, `coffee_strength`, `sweetness`, `syrup`, `toppings`, `special_instructions`) VALUES
(1, 1, 'Oat Milk', 'Strong', 'Medium', 'Vanilla', 'Whipped Cream', 'Less ice'),
(2, 3, 'Full Cream', 'Medium', 'Low', 'None', 'None', 'Extra hot');

-- --------------------------------------------------------

--
-- Table structure for table `customizer_options`
--

CREATE TABLE `customizer_options` (
  `option_id` int(11) NOT NULL,
  `category` varchar(30) NOT NULL,
  `option_code` varchar(50) NOT NULL,
  `option_name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `visual_color` varchar(30) DEFAULT NULL,
  `intensity` int(11) DEFAULT NULL,
  `volume_ml` int(11) DEFAULT NULL,
  `visual_height` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customizer_options`
--

INSERT INTO `customizer_options` (`option_id`, `category`, `option_code`, `option_name`, `description`, `price`, `visual_color`, `intensity`, `volume_ml`, `visual_height`, `sort_order`, `is_active`) VALUES
(1, 'roast', 'signature', 'Signature Atelier', 'Chikmagalur & Colombia washed beans.', 0.00, '#551F1B', 75, NULL, NULL, 1, 1),
(2, 'roast', 'ethiopian', 'Yirgacheffe Floral', 'Light sun-dried heirloom roast.', 0.00, '#8D4C45', 50, NULL, NULL, 2, 1),
(3, 'roast', 'sumatra', 'Dark Sumatra', 'Heavy body, slow drum roasted.', 0.00, '#28110F', 95, NULL, NULL, 3, 1),
(4, 'size', 'tall', 'Regular', 'Tall - 250ml', 220.00, NULL, NULL, 250, 180, 1, 1),
(5, 'size', 'grande', 'Large', 'Grande - 350ml', 260.00, NULL, NULL, 350, 220, 2, 1),
(6, 'size', 'venti', 'Jumbo', 'Venti - 450ml', 290.00, NULL, NULL, 450, 250, 3, 1),
(7, 'temperature', 'hot', 'Hot', NULL, 0.00, NULL, NULL, NULL, NULL, 1, 1),
(8, 'temperature', 'iced', 'Iced', NULL, 0.00, NULL, NULL, NULL, NULL, 2, 1),
(9, 'ice', 'light', 'Less Ice', NULL, 0.00, NULL, NULL, NULL, NULL, 1, 1),
(10, 'ice', 'regular', 'Standard Chill', NULL, 0.00, NULL, NULL, NULL, NULL, 2, 1),
(11, 'ice', 'extra', 'Extra Cold (Glacier)', NULL, 0.00, NULL, NULL, NULL, NULL, 3, 1),
(12, 'milk', 'Barista Oat', 'Barista Oat Milk', 'Velvety & naturally sweet grain finish.', 45.00, '#EDE2D3', NULL, NULL, NULL, 1, 1),
(13, 'milk', 'Whole Milk', 'Whole Dairy Milk', 'Rich, decadent organic pasteurized dairy.', 0.00, '#FFFDF9', NULL, NULL, NULL, 2, 1),
(14, 'milk', 'Skimmed Milk', 'Skimmed Light', 'Crisp texture, low calorie brew body.', 0.00, '#F4F4F6', NULL, NULL, NULL, 3, 1),
(15, 'milk', 'Creamy Almond', 'Creamy Almond', 'Subtle roasted almond note, zero cane sugar.', 45.00, '#EBE3D7', NULL, NULL, NULL, 4, 1),
(16, 'milk', 'Coconut Milk', 'Tropical Coconut', 'Silky creaminess with exotic botanical lift.', 40.00, '#FAF8F5', NULL, NULL, NULL, 5, 1),
(17, 'milk', 'No Milk (Black)', 'Pure Black', 'Pure espresso with hot or iced filtered water.', 0.00, 'transparent', NULL, NULL, NULL, 6, 1),
(18, 'shots', '1', 'Single Shot', '30ml Espresso', 0.00, NULL, NULL, 30, NULL, 1, 1),
(19, 'shots', '2', 'Double Shot', '60ml Extraction', 0.00, NULL, NULL, 60, NULL, 2, 1),
(20, 'shots', '3', 'Triple Shot', '90ml Pure Fuel', 40.00, NULL, NULL, 90, NULL, 3, 1),
(21, 'addon', 'whip', 'Whipped Cream', 'Whipped cream finish', 35.00, NULL, NULL, NULL, 14, 1, 1),
(22, 'addon', 'cold-foam', 'Velvet Cold Foam', 'Vanilla cold foam', 35.00, NULL, NULL, NULL, 16, 2, 1),
(23, 'addon', 'cinnamon-dust', 'Cinnamon Dust', 'Cinnamon dusting', 20.00, NULL, NULL, NULL, 6, 3, 1),
(24, 'addon', 'cocoa-nib', 'Cocoa Nib Crunch', 'Cocoa nib crumble', 25.00, NULL, NULL, NULL, 8, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `custom_drink_customizations`
--

CREATE TABLE `custom_drink_customizations` (
  `customization_id` int(11) NOT NULL,
  `roast_code` varchar(50) NOT NULL,
  `size_code` varchar(50) NOT NULL,
  `temperature_code` varchar(50) NOT NULL,
  `ice_code` varchar(50) DEFAULT NULL,
  `milk_code` varchar(50) NOT NULL,
  `shots_code` varchar(50) NOT NULL,
  `addon_code` varchar(50) DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `food_items`
--

CREATE TABLE `food_items` (
  `food_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `food_items`
--

INSERT INTO `food_items` (`food_id`, `name`, `category`, `description`, `price`) VALUES
(1, 'Veggie Sandwich', 'Sandwich', 'Grilled vegetable sandwich', 160.00),
(2, 'Chocolate Muffin', 'Muffin', 'Soft chocolate muffin', 100.00),
(3, 'Butter Croissant', 'Pastry', 'Fresh buttery croissant', 120.00),
(4, 'Chocolate Cake', 'Cake', 'Rich chocolate cake slice', 180.00),
(5, 'Chocolate Cookie', 'Cookie', 'Crispy chocolate cookie', 80.00);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `status` varchar(30) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `order_date`, `total_amount`, `status`) VALUES
(1, 1, '2026-08-29 20:09:24', 330.00, 'Pending'),
(2, 2, '2026-08-29 20:09:24', 280.00, 'Preparing'),
(3, 3, '2026-08-29 20:09:24', 260.00, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `beverage_id` int(11) DEFAULT NULL,
  `food_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `order_id`, `beverage_id`, `food_id`, `quantity`, `price`) VALUES
(1, 1, 2, 1, 1, 180.00),
(2, 1, NULL, 4, 1, 150.00),
(3, 2, 1, 3, 1, 150.00),
(4, 3, 4, NULL, 1, 170.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `phone`, `password`, `created_at`) VALUES
(1, 'Test User', 'test@gmail.com', NULL, 'Test@123', '2026-11-22 15:50:15'),
(2, 'Coffee User', NULL, '9876543210', 'Coffee@123', '2026-11-22 15:50:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beverages`
--
ALTER TABLE `beverages`
  ADD PRIMARY KEY (`beverage_id`);

--
-- Indexes for table `cafe_locations`
--
ALTER TABLE `cafe_locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customizations`
--
ALTER TABLE `customizations`
  ADD PRIMARY KEY (`customization_id`),
  ADD KEY `order_item_id` (`order_item_id`);

--
-- Indexes for table `customizer_options`
--
ALTER TABLE `customizer_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `unique_option` (`category`,`option_code`);

--
-- Indexes for table `custom_drink_customizations`
--
ALTER TABLE `custom_drink_customizations`
  ADD PRIMARY KEY (`customization_id`);

--
-- Indexes for table `food_items`
--
ALTER TABLE `food_items`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `beverage_id` (`beverage_id`),
  ADD KEY `food_id` (`food_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beverages`
--
ALTER TABLE `beverages`
  MODIFY `beverage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `cafe_locations`
--
ALTER TABLE `cafe_locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customizations`
--
ALTER TABLE `customizations`
  MODIFY `customization_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customizer_options`
--
ALTER TABLE `customizer_options`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `custom_drink_customizations`
--
ALTER TABLE `custom_drink_customizations`
  MODIFY `customization_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food_items`
--
ALTER TABLE `food_items`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customizations`
--
ALTER TABLE `customizations`
  ADD CONSTRAINT `customizations_ibfk_1` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`order_item_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`beverage_id`) REFERENCES `beverages` (`beverage_id`),
  ADD CONSTRAINT `order_items_ibfk_3` FOREIGN KEY (`food_id`) REFERENCES `food_items` (`food_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
