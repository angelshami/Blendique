---
name: BLENDIQUE
colors:
  surface: '#fcf8fb'
  surface-dim: '#dcd9dc'
  surface-bright: '#fcf8fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#f0edef'
  surface-container-high: '#eae7ea'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1d'
  on-surface-variant: '#534341'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#867370'
  outline-variant: '#d8c1bf'
  surface-tint: '#8d4c45'
  primary: '#551f1b'
  on-primary: '#ffffff'
  primary-container: '#71352f'
  on-primary-container: '#f3a096'
  inverse-primary: '#ffb4ab'
  secondary: '#3a637b'
  on-secondary: '#ffffff'
  secondary-container: '#b9e2ff'
  on-secondary-container: '#3d657e'
  tertiary: '#23333b'
  on-tertiary: '#ffffff'
  tertiary-container: '#394952'
  on-tertiary-container: '#a7b8c2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#390b08'
  on-primary-fixed-variant: '#71352f'
  secondary-fixed: '#c5e7ff'
  secondary-fixed-dim: '#a3cce8'
  on-secondary-fixed: '#001e2d'
  on-secondary-fixed-variant: '#204b62'
  tertiary-fixed: '#d4e5f0'
  tertiary-fixed-dim: '#b8c9d4'
  on-tertiary-fixed: '#0d1d25'
  on-tertiary-fixed-variant: '#394952'
  background: '#fcf8fb'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e4'
typography:
  display:
    fontFamily: Syne
    fontSize: 4.5rem
    fontWeight: '800'
    lineHeight: 4.75rem
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Syne
    fontSize: 2.75rem
    fontWeight: '800'
    lineHeight: 3rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Syne
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.25rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Syne
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.35rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Syne
    fontSize: 1.375rem
    fontWeight: '700'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.35rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '700'
    lineHeight: 1.25rem
    letterSpacing: 0.04em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '700'
    lineHeight: 1rem
    letterSpacing: 0.06em
  label-sticker:
    fontFamily: Syne
    fontSize: 0.75rem
    fontWeight: '800'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2rem
  margin: 1.25rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

This design system expresses a high-energy, retro-editorial aesthetic for a contemporary coffee experience. It balances the artisanal weight of European cafe heritage with the irreverent, graphic energy of modern lifestyle publication design. 

The emotional tone is confident, tactile, and sensory. Interfaces reject standard muted neutrals and beige cafe motifs in favor of deliberate color tension: velvety burgundy grounded against crisp powder blues and rich buttermilk cream. Visual rhythm pulls inspiration from printed broadsheets, record covers, and contemporary food journals—featuring oversized typography, expressive badge elements, sticker labels, and structured asymmetry. 

Interactions feel tangible and immediate. Micro-interactions echo physical paper goods and packaging via slight spring-based offsets, crisp hairline borders, and graphic label overlays.

## Colors

The palette establishes a high-contrast chromatic dialog between intense, earthy richness and playful levity:

- **Primary (`#71352F` — Deep Burgundy):** Carries the visual weight. Used for hero buttons, signature product tags, key brand headers, and bold framing devices.
- **Secondary (`#A9D2EE` — Powder Blue):** Acts as the energetic disruptor. Injected through interactive elements, sticker pills, prominent highlights, and hover inversions to break culinary conventions.
- **Tertiary (`#D9EAF5` — Pastel Blue):** Functions as a delicate surface tint for nested containers, table strips, contextual banners, and subtle card backplates.
- **Neutral Canvas (`#F5EFE6` — Warm Cream):** The global page background. Replaces raw white with a tactile, paper-like warmth across all layouts.
- **Neutral Text & Structure (`#171719` — Charcoal Black):** Anchors headlines, high-priority body copy, and crisp structural borders with ink-on-newsprint authority.
- **Pure White (`#FFFFFF`):** Reserved strictly for elevated content cards, input wells, and crisp graphic contrast against cream surfaces.

Color pairings prioritize impact: Deep Burgundy text directly over Powder Blue surfaces, or Charcoal Black over Warm Cream. Never tint burgundy with muddy gray; preserve its fruit-forward wine tone.

## Typography

The typography couples the architectural, avant-garde curves of Syne with the geometric clarity of Plus Jakarta Sans.

- **Display & Headings (Syne):** Display type should feel editorial and expansive. Headlines are set tight with slightly negative tracking, prioritizing dramatic scale differences to emulate magazine spreads.
- **Body & Functional Copy (Plus Jakarta Sans):** Balances Syne’s theatricality with open counters and balanced proportions, ensuring tasting notes, origin descriptions, and transaction data remain effortless to scan.
- **Sticker Labels & Badges (`label-sticker`):** Always rendered in uppercase using Syne Extra Bold. Used across seasonal tags, origin labels, roast meters, and sale indicators.

## Layout & Spacing

Layouts adhere to a 12-column fluid grid on desktop (with 2rem gutters) that collapses to a 6-column grid on tablet, and a 4-column structure on mobile devices.

The spatial logic embraces editorial asymmetrical density: wide-open hero viewports with generous section padding (`space-2xl`) directly abut tightly-packed, rhythmic product grids and sticker clusters. 

Layout rules:
- Outer canvas margins remain uncompromised to preserve the print-journal frame.
- Structural panels alternate between full-bleed burgundy/powder blue blocks and boxed cards floating over the `#F5EFE6` Warm Cream baseline.
- Content groupings rely primarily on spatial cadence (`space-md` between metadata, `space-xl` between modular sections) rather than divider lines alone.

## Elevation & Depth

Visual hierarchy uses physical, graphic layering rather than diffused photorealistic shadows.

1. **Flat Tonal Stacking:** Surfaces overlap cleanly. Product cards set in `#FFFFFF` rest on `#F5EFE6` or `#D9EAF5` surfaces without vertical blur, delineated by a crisp 1.5px border in `#171719` or `#71352F`.
2. **Hard Retro Offset (The "Sticker Shadow"):** For primary callouts, floating tags, and interactive button hover states, utilize a solid, non-diffused hard shadow offset (`3px 3px 0px #171719`). This evokes screen-printed ephemera and physical cafe loyalty tokens.
3. **Ghost Borders:** Secondary and structural containers leverage soft low-opacity framing (`rgba(23, 23, 25, 0.08)`) when placed directly against cream surfaces to maintain structure without clutter.
4. **Modals & Flyouts:** Backdrop overlays utilize `#171719` at 40% opacity with no blur, prioritizing graphic punch over glass effects.

## Shapes

The shape system centers on pill-shaped geometry juxtaposed with gently softened rectangles.

- **Primary Interactive Elements:** Buttons, chips, category filter capsules, and search bars use complete pill contours (`roundedness: 3`, or `9999px` border-radius).
- **Cards & Visual Containers:** Product tiles, recipe containers, and feature banners use softened corners (`rounded-xl` or `1.5rem` / `24px`), creating smooth physical framing that complements the circular typography forms in Syne.
- **Badges & Micro-Stickers:** Badges combine pill shapes with slight intentional rotational transforms (`-2deg` to `+3deg`) to enforce an informal, hand-placed label feel.

## Components

### Buttons
- **Primary:** Pill-shaped (`rounded-full`), solid Deep Burgundy (`#71352F`) background, `#FFFFFF` text, with Syne or Plus Jakarta Sans bold weight. Hover triggers a powder blue accent border or solid offset drop-shadow (`3px 3px 0px #171719`).
- **Secondary (Playful Accent):** Powder Blue (`#A9D2EE`) background, Deep Burgundy (`#71352F`) text, and a crisp 1.5px border.
- **Tertiary / Ghost:** Pill outline using Deep Burgundy or Charcoal with no background fill; background fills with `#D9EAF5` on hover.

### Chips & Stickers
- **Product Badges:** Pill-shaped, high-contrast badges (e.g., `#A9D2EE` background with `#71352F` text; or `#71352F` background with `#F5EFE6` text). Set in `label-sticker` Syne typography.
- **Filter Chips:** Capsule buttons with `#FFFFFF` background and `#171719` text. Selected state inverts directly to `#71352F` with white text.

### Product & Editorial Cards
- **Base Structure:** White (`#FFFFFF`) or Pastel Blue (`#D9EAF5`) cards with `rounded-2xl` corners, framed by a 1.5px hairline border in `#171719` or Deep Burgundy.
- **Image Treatment:** Photography features natural editorial lighting, cropped cleanly inside rounded sub-containers, often accompanied by an overlapping sticker badge anchored in the corner.
- **Metadata Layout:** Tasting notes, roast profiles, and process methods are listed using `label-md` uppercase tokens in horizontal flex wraps.

### Form Inputs
- **Fields:** Pill-shaped single-line inputs or generous `rounded-xl` text areas on `#FFFFFF` backgrounds. Outlines use a crisp 1.5px `#171719` stroke.
- **Focus State:** Border shifts to `#71352F` with an outer ring tinted in `#A9D2EE`.
- **Checkboxes & Radios:** Radios remain circular; checkboxes use softened rounded squares (`rounded-md`). Active state fills solid `#71352F` with an ink-white interior mark.

### Cafe-Specific Components
- **Roast Level Meter:** Minimal horizontal gauge segmented by rounded pills, filling progressively from `#D9EAF5` up to `#71352F`.
- **Tasting Profile Discs:** Floating micro-capsules highlighting flavour descriptors (e.g., *Bergamot*, *Black Cherry*, *Brioche*) set in Powder Blue with Burgundy ink.